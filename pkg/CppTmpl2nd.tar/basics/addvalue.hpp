template<int Val, typename T>
T addValue (T x)
{
  return x + Val;
}
