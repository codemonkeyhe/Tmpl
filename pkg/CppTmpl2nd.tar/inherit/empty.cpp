#include <iostream>

class EmptyClass {
};

int main()
{
  std::cout << "sizeof(EmptyClass): " << sizeof(EmptyClass) << '\n';
}
